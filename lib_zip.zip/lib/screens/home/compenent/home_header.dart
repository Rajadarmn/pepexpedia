import 'package:flutter/material.dart';
import 'package:ui_ecommerce/screens/home/compenent/icon_btn_with_counter.dart';
import 'package:ui_ecommerce/screens/home/compenent/search_field.dart';

class HomeHeader extends StatelessWidget {
  const HomeHeader({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          SeachField(),
          IconBtnWithCounter(
            svgSrc: "assets/icons/Cart Icon.svg",
            num0fItems: 0,
            press: () {
            },
          ),
            IconBtnWithCounter(
            svgSrc: "assets/icons/Cart Icon.svg",
            num0fItems: 4,
            press: () {
            },
          )
        ],
      ),
    );
  }
}



